import os, sqlite3, secrets
from functools import wraps
from flask import (Flask, g, render_template, request, redirect,
                   url_for, session, flash, abort)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-change-me")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin")
DB = os.path.join(app.root_path, "shop.db")

CATS = ["Футболки", "Верхняя одежда", "Брюки", "Платья"]
EM = {"Футболки": "👕", "Верхняя одежда": "🧥", "Брюки": "👖", "Платья": "👗"}
STATUSES = ["Новый", "Оплачен", "Отправлен", "Доставлен"]
SEED = [
    ("Футболка оверсайз", "Футболки", 2490, "#DCE4FF", "S,M,L,XL"),
    ("Футболка базовая", "Футболки", 1590, "#E9EEF7", "S,M,L"),
    ("Пуховик короткий", "Верхняя одежда", 12990, "#C9D3EA", "M,L,XL"),
    ("Тренч классический", "Верхняя одежда", 9990, "#F0E6D6", "S,M,L"),
    ("Брюки прямые", "Брюки", 4590, "#D6DCE8", "S,M,L,XL"),
    ("Джинсы широкие", "Брюки", 5290, "#B9C7E6", "M,L,XL"),
    ("Платье миди", "Платья", 6490, "#F3DDE4", "XS,S,M"),
    ("Платье льняное", "Платья", 5790, "#E3EBDD", "S,M,L"),
]

# ---------- База данных ----------
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(_):
    con = g.pop("db", None)
    if con:
        con.close()

def init_db():
    con = sqlite3.connect(DB)
    con.executescript("""
    create table if not exists products(
        id integer primary key autoincrement, name text not null,
        cat text not null, price integer not null,
        color text not null default '#DCE4FF', sizes text not null);
    create table if not exists orders(
        id integer primary key autoincrement, created text default current_timestamp,
        name text, phone text, total integer, status text default 'Новый');
    create table if not exists order_items(
        order_id integer, name text, size text, qty integer, price integer);
    """)
    if not con.execute("select count(*) from products").fetchone()[0]:
        con.executemany("insert into products(name,cat,price,color,sizes) values(?,?,?,?,?)", SEED)
    con.commit()
    con.close()

# ---------- Защита форм и общие данные шаблонов ----------
@app.before_request
def check_csrf():
    if request.method == "POST":
        token = session.get("csrf")
        if not token or not secrets.compare_digest(token, request.form.get("csrf", "")):
            abort(400)

@app.context_processor
def common():
    session.setdefault("csrf", secrets.token_hex(16))
    return dict(csrf=session["csrf"], EM=EM, CATS=CATS, STATUSES=STATUSES,
                cart_count=sum(session.get("cart", {}).values()),
                is_admin=session.get("admin", False))

def admin_required(f):
    @wraps(f)
    def wrapper(*a, **kw):
        if not session.get("admin"):
            return redirect(url_for("login"))
        return f(*a, **kw)
    return wrapper

# ---------- Покупатель ----------
@app.route("/")
def shop():
    cat, q, sort = request.args.get("cat", ""), request.args.get("q", "").strip(), request.args.get("sort", "")
    sql, args = "select * from products where 1=1", []
    if cat in CATS:
        sql += " and cat=?"; args.append(cat)
    if q:
        sql += " and name like ?"; args.append(f"%{q}%")
    sql += {"asc": " order by price", "desc": " order by price desc"}.get(sort, " order by id desc")
    return render_template("shop.html", products=db().execute(sql, args).fetchall(),
                           cat=cat, q=q, sort=sort)

def cart_items():
    items, total = [], 0
    for key, qty in session.get("cart", {}).items():
        pid, size = key.split(":", 1)
        p = db().execute("select * from products where id=?", (pid,)).fetchone()
        if p:
            items.append(dict(key=key, p=p, size=size, qty=qty))
            total += p["price"] * qty
    return items, total

@app.post("/cart/add")
def cart_add():
    pid, size = request.form.get("id", ""), request.form.get("size", "")
    p = db().execute("select * from products where id=?", (pid,)).fetchone()
    if not p or size not in p["sizes"].split(","):
        abort(400)
    cart = session.get("cart", {})
    key = f"{pid}:{size}"
    cart[key] = cart.get(key, 0) + 1
    session["cart"] = cart
    flash("Добавлено в корзину")
    return redirect(request.referrer or url_for("shop"))

@app.route("/cart")
def cart():
    items, total = cart_items()
    return render_template("cart.html", items=items, total=total)

@app.post("/cart/change")
def cart_change():
    cart, key = session.get("cart", {}), request.form.get("key", "")
    if key in cart:
        cart[key] += 1 if request.form.get("d") == "+" else -1
        if cart[key] < 1:
            del cart[key]
        session["cart"] = cart
    return redirect(url_for("cart"))

@app.post("/cart/checkout")
def checkout():
    items, total = cart_items()
    name, phone = request.form.get("name", "").strip(), request.form.get("phone", "").strip()
    if not items or not name or sum(c.isdigit() for c in phone) < 6:
        flash("Укажите имя и телефон")
        return redirect(url_for("cart"))
    con = db()
    oid = con.execute("insert into orders(name,phone,total) values(?,?,?)", (name, phone, total)).lastrowid
    con.executemany("insert into order_items values(?,?,?,?,?)",
                    [(oid, i["p"]["name"], i["size"], i["qty"], i["p"]["price"]) for i in items])
    con.commit()
    session.pop("cart", None)
    flash(f"Заказ №{oid} оформлен. Мы позвоним вам")
    return redirect(url_for("shop"))

# ---------- Админ ----------
@app.route("/admin/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if secrets.compare_digest(request.form.get("password", "").encode(), ADMIN_PASSWORD.encode()):
            session["admin"] = True
            return redirect(url_for("admin"))
        flash("Неверный пароль")
    return render_template("login.html")

@app.post("/admin/logout")
def logout():
    session.pop("admin", None)
    return redirect(url_for("shop"))

@app.route("/admin")
@admin_required
def admin():
    con = db()
    stats = dict(
        products=con.execute("select count(*) from products").fetchone()[0],
        orders=con.execute("select count(*) from orders").fetchone()[0],
        revenue=con.execute("select coalesce(sum(total),0) from orders").fetchone()[0],
        new=con.execute("select count(*) from orders where status='Новый'").fetchone()[0])
    edit = None
    if request.args.get("edit"):
        edit = con.execute("select * from products where id=?", (request.args["edit"],)).fetchone()
    elif "new" in request.args:
        edit = dict(id="", name="", cat=CATS[0], price="", color="#DCE4FF", sizes="S,M,L")
    return render_template("admin.html", tab="products", stats=stats, edit=edit,
                           products=con.execute("select * from products order by id desc").fetchall())

@app.post("/admin/product")
@admin_required
def product_save():
    f = request.form
    try:
        price = int(f["price"])
    except ValueError:
        price = 0
    data = (f.get("name", "").strip(), f.get("cat"), price, f.get("color", "#DCE4FF"), f.get("sizes", "").strip())
    if not data[0] or data[1] not in CATS or price <= 0 or not data[4]:
        flash("Заполните название, категорию, цену и размеры")
        return redirect(url_for("admin", new=1))
    con = db()
    if f.get("id"):
        con.execute("update products set name=?,cat=?,price=?,color=?,sizes=? where id=?", (*data, f["id"]))
    else:
        con.execute("insert into products(name,cat,price,color,sizes) values(?,?,?,?,?)", data)
    con.commit()
    flash("Товар сохранён")
    return redirect(url_for("admin"))

@app.post("/admin/product/<int:pid>/delete")
@admin_required
def product_delete(pid):
    db().execute("delete from products where id=?", (pid,))
    db().commit()
    flash("Товар удалён")
    return redirect(url_for("admin"))

@app.route("/admin/orders")
@admin_required
def admin_orders():
    con = db()
    orders = con.execute("select * from orders order by id desc").fetchall()
    items = {}
    for r in con.execute("select * from order_items"):
        items.setdefault(r["order_id"], []).append(r)
    return render_template("admin.html", tab="orders", orders=orders, items=items, stats=None)

@app.post("/admin/orders/<int:oid>/status")
@admin_required
def order_status(oid):
    s = request.form.get("status")
    if s in STATUSES:
        db().execute("update orders set status=? where id=?", (s, oid))
        db().commit()
        flash("Статус обновлён")
    return redirect(url_for("admin_orders"))

init_db()
if __name__ == "__main__":
    app.run(debug=True)
